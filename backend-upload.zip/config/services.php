<?php

return [

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'midtrans' => [
        'server_key'  => env('MIDTRANS_SERVER_KEY'),
        'client_key'  => env('MIDTRANS_CLIENT_KEY'),
        'is_sandbox'  => env('MIDTRANS_IS_SANDBOX', true),
    ],

    'whatsapp' => [
        'url' => env('WHATSAPP_SERVICE_URL', 'http://localhost:3001'),
    ],

];
